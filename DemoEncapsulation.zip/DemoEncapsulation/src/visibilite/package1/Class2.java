package visibilite.package1;

public class Class2 {

	public Class2() {
		
		ClassPublic maClasse = new ClassPublic();
//		Recup propriété public 
		System.out.println("publicString : " + maClasse.publicString);
	
//		Recup propriété privée : provoque une erreur, la propriété est
//		private et ne peut pas être accédée depuis une autre classe
//		décommenter la ligne pour voire ...
//		System.out.println("privateString : " + maClasse.privateString );
		
//		Recup propriété protected
		System.out.println("protectedString : " + maClasse.protectedString);
		
//		Recup constante d'instance		
		System.out.println("finalString : " + maClasse.finalString );
		
//		Recup propriété de classe		
		System.out.println("staticInt : " + ClassPublic.staticInt );
		
//		Recup constante de classe		
		System.out.println("staticFinalString : " + ClassPublic.staticFinalString );

	}

}
