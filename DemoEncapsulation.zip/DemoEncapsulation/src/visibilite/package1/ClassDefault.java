package visibilite.package1;

class ClassDefault {
	
	private static int nbOccurences;
	
	public ClassDefault() {
		nbOccurences++;
	}
	public int getNbOccurences() {
		return nbOccurences;
	}

}
