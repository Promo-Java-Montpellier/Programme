package visibilite.package1;

public class ClassMain {

	
	public static void main(String[] args) {
		
		System.out.println("----------    ClassPublic dans main --------------");
		ClassPublic maClasse = new ClassPublic();
		
//		Recup propriété public 
		System.out.println("publicString : " + maClasse.publicString);
	
//		Recup propriété privée : provoque une erreur, la propriété est
//		private et ne peut pas étre accédée depuis une autre classe
//		décommentez la ligne pour constater  l'erreur...
//		System.out.println("privateString : " + maClasse.privateString );
		
//		Recup propriété protected
		System.out.println("protectedString : " + maClasse.protectedString);
		
//		Recup propriété default
		System.out.println("defaultString : " + maClasse.defaultString);
		
//		Recup constante d'instance		
		System.out.println("finalStringPublic    : " + maClasse.finalString );
		System.out.println("finalStringDefault   : " + maClasse.finalStringD );
		System.out.println("finalStringProtected : " + maClasse.finalStringP );
		
//		Recup propriété de classe		
		System.out.println("staticInt : " + ClassPublic.staticInt );		
		System.out.println("staticFinalString : " + ClassPublic.staticFinalString );
		
		//-- Divers --------------------------------------		
		System.out.println("----------    accès à Class2 depuis ClassMain (même package) --------------");
		Class2 maClass2 = new Class2();  //Class2 est public <=> accès autorisé depuis ClassMain
		
		System.out.println("----------   accès à  defaultClass depusi ClassMain (même package)--------------");
		ClassDefault maClass3 = new ClassDefault(); //ClassDefault est dans le même package que son appelant <=> visibilité autorisée donc !!
		System.out.println("defaultClass : " + maClass3.getNbOccurences() );  
	}

}
