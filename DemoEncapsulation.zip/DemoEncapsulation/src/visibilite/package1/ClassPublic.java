package visibilite.package1;

public class ClassPublic {
	
// 	Propriétés de classe
	public static 	int	   staticInt = 0;
	public static final    String staticFinalString = "staticFinalString"; //	Constante de classe
	
//	Propriété d'instance
	public 			String publicString;
	private 		String privateString;
	protected 		String protectedString;
					String defaultString;

	final		 	String finalStringD = "finalStringDefault";		// 	Constante d'instance		
	public    final String finalString  = "finalStringPublic";      // 	Constante d'instance
	protected final	String finalStringP = "finalStringProtected";   // 	Constante d'instance
	
//  test inutile voir privateString
//	private   final String finalSringPr = "finalStringPrivate";
	
// méthodes ------------------------------------------
//	Constructeur de la classe
	public ClassPublic(){
		staticInt++;
		publicString 	= "publicString";
		privateString 	= "privateString";
		protectedString = "protectedString";
		defaultString 	= "defaultString";
	}
	
	public 		void setFinalString() {
//		cette ligne provoque une erreur. C'est une constante
		// this.finalString = "Coucou";
		
	}
	
	public 		String getPrivateString() {
		return privateString;
	}
	
	private 	String getPublicString() {
		return publicString;
	}
	
	protected 	String getfinalString() {
		return finalString;
	}
	

}
