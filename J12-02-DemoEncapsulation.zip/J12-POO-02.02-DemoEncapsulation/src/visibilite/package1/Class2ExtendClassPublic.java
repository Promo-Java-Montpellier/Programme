package visibilite.package1;

public class Class2ExtendClassPublic extends ClassPublic {

	public Class2ExtendClassPublic() {
		
		this.publicString = "coucou";
		this.protectedString = "truc";
//		this.privateString = "marche pas"; 	// non visible dans les classes d�riv�es
	
		// ----------------------------------------------------------------
		ClassPublic maClasse = new ClassPublic();
//		Recup propri�t� public 
		System.out.println("publicString : " + maClasse.publicString);
	
//		Recup propri�t� priv�e : provoque une erreur, la propri�t� est
//		private et ne peut pas �tre acc�d�e depuis une autre classe
//		d�commenter la ligne pour voire ...
		// System.out.println("privateString : " + maClasse.privateString );
		
//		Recup propri�t� protected
		System.out.println("protectedString : " + maClasse.protectedString);
		
//		Recup constante d'instance		
		System.out.println("finalString : " + maClasse.finalString );
		
//		Recup propri�t� de classe		
		System.out.println("staticInt : " + ClassPublic.staticInt );
		
//		Recup constante de classe		
		System.out.println("staticFinalString : " + ClassPublic.staticFinalString );

	}

}
