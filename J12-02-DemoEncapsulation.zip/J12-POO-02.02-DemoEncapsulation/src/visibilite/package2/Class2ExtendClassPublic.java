package visibilite.package2;
import visibilite.package1.*;

public class Class2ExtendClassPublic extends ClassPublic {

	public Class2ExtendClassPublic() {
		
		this.publicString = "coucou";
		this.protectedString = "truc";		// accede à la propriete protected
		// this.privateString = "marche pas"; 	// non visible dans les classes 
											// dérivées
		
		
		ClassPublic maClasse = new ClassPublic();
//		Recup propriété public 
		System.out.println("publicString : " + maClasse.publicString);
	
//		Recup propriété privée : provoque une erreur, la propriété est
//		private et ne peut pas être accèdée depuis une autre classe
//		décommenter la ligne pour voire ...
		// System.out.println("privateString : " + maClasse.privateString );
		
//		Recup propriété protected => erreur
//		Dans ce cas, nous ne sommes pas dans l'héritage. On a seulement
//		instancié un nouvel objet donc protected ,ne se voit pas.
		// System.out.println("protectedString : " + maClasse.protectedString);
		
//		Recup constante d'instance		
		System.out.println("finalString : " + maClasse.finalString );
		
//		Recup propriété de classe		
		System.out.println("staticInt : " + maClasse.staticInt );
		
//		Recup constante de classe		
		System.out.println("staticFinalString : " + maClasse.staticFinalString );

	}

}
