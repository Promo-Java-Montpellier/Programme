package visibilite.package2;

import visibilite.package1.*;


public class ClassMainP2 {
	public static void main(String[] args) {
		
		System.out.println("----------   accès à  ClassPublic depuis un autre package que le sien--------------");
		
//      Pour voir ClassPublic, il faut importer le package1
		ClassPublic maClasse = new ClassPublic();
		
//		Recup propriété public (visible depuis un autre package)
		System.out.println("publicString : " + maClasse.publicString);
	
//		Recup propriété protected : provoque une erreur de visibilité)
		// System.out.println("protectedString : " + maClasse.protectedString);
		
//		Recup propriété default : provoque une erreur de visibilité)
		// System.out.println("defaultString : " + maClasse.defaultString);
		
//		Recup public constante d'instance : 		
		System.out.println   ("finalStringPublic    : " + maClasse.finalString );
//		Recup default  constante d'instance provoque une erreur de visibilité
		// System.out.println("finalStringDefault   : " + maClasse.finalStringD );
//		Recup protected constante d'instance provoque une erreur de visibilité
		// System.out.println("finalStringProtected : " + maClasse.finalStringP );
		
//		Recup propriété public  de classe		
		System.out.println("staticInt : " + ClassPublic.staticInt );
		
//		Recup constante public de classe		
		System.out.println("staticFinalString : " + ClassPublic.staticFinalString );
		
		
		
		System.out.println("----------    acès à Class2 depuis  classMain2 (depuis un autre package  --------------");
		Class2 maClass2 = new Class2();  //Class2 est public on y accède de partout

		System.out.println("----------  acès à   defaultClass --------------");
		// DefaultClass maClass3 = new DefaultClass();  //Default Class n'est accessible que depuis le même package 
		// provoque une erreur de visibilité
		
	}

}
